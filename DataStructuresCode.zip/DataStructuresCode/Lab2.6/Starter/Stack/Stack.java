package com.packt.datastructuresandalg.lesson2.stack;

import com.packt.datastructuresandalg.lesson2.linkedlist.LinkedListNode;


public class Stack<V> {
    private LinkedListNode<V> head;

    public void push(V item) {
//        pseudo-code
//        if (item != null)
//            node = new LinkedListNode(item, head)
//            head = node

    }

    public Optional<V> pop() {
//      pseudo-code
//        if (head != null)
              
//             node = head
//             head = node.next
//             return node.value
//        return null
    }
}
